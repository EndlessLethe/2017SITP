package com.sitp2017.hujiepingtai6;

import android.app.ActivityOptions;
import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class LoginPage extends AppCompatActivity {

    private EditText loginPhoneNumberInput;

    private EditText loginPasswordInput;

    private Button loginApp;

    private TextView signOn;

    private void initSurface() {
        getWindow().requestFeature(Window.FEATURE_CONTENT_TRANSITIONS);
        StatusBarColorUtil.StatusBarLightMode(this);
    }

    private void findViews() {
        loginPhoneNumberInput = (EditText) findViewById(R.id.login_phone_number_input);
        loginPasswordInput = (EditText) findViewById(R.id.login_password_input);

        loginApp = (Button) findViewById(R.id.login_app);
        loginApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginPage.this, MainPage.class);
                startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(LoginPage.this).toBundle());
            }
        });

        signOn = (TextView) findViewById(R.id.sign_on);
        signOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginPage.this, PhoneNumberInputPage.class);
                startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(LoginPage.this).toBundle());
            }
        });

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ActivityCollector.addActivity(this);
        super.onCreate(savedInstanceState);
        initSurface();
        setContentView(R.layout.activity_login_page);

        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null) {
            actionBar.hide();
        }
        findViews();
    }
}
